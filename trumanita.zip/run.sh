#!/usr/bin/with-contenv bashio
set -e

echo "🔧 Trumanita add-on starter..."

CONFIG_ENV="/config/.env"
APP_DIR="/opt/trumanita"

echo "Genererer .env basert på add-on konfig..."

cat <<EOF > "${CONFIG_ENV}"
MQTT_HOST=$(bashio::config 'mqtt_host')
MQTT_PORT=$(bashio::config 'mqtt_port')
MQTT_USERNAME=$(bashio::config 'mqtt_username')
MQTT_PASSWORD=$(bashio::config 'mqtt_password')

MQTT_TOPIC=$(bashio::config 'mqtt_topic')
MQTT_TOPIC_REPORT=$(bashio::config 'mqtt_topic_report')

SLEEP_DURATION_US=$(bashio::config 'sleep_duration_us')
MQTT_PUBLISH_INTERVAL=$(bashio::config 'mqtt_publish_interval')

UART_DEVICE=$(bashio::config 'uart_device')
UART_BAUDRATE=$(bashio::config 'uart_baudrate')
EOF

echo ".env generert i ${CONFIG_ENV}:"
cat "${CONFIG_ENV}"

# Trumanita forventer .env i arbeidskatalogen sin: /opt/trumanita/.env
cp "${CONFIG_ENV}" "${APP_DIR}/.env"
echo "Kopierte ${CONFIG_ENV} til ${APP_DIR}/.env"

cd "${APP_DIR}"
echo "Innhold i /opt/trumanita:"
ls -l

echo "Starter LINsenddirect..."
exec ./LINsenddirect
